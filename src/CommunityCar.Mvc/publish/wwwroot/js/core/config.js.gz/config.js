/**
 * Global Configuration
 */
window.Config = {
    appName: 'Community Car',
    version: '1.0.0',
    debug: true
};
